import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;


@Entity
@Table(name="FeeDetails")
public class FeeDetails 
{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	int f_id;
	@OneToOne(mappedBy="")
	double totalFees;
	int noOfInstallments;
	
	@Override
	public String toString() {
		return "FeeDetails [f_id=" + f_id + ", totalFees=" + totalFees
				+ ", noOfInstallments=" + noOfInstallments + "]";
	}

	public int getF_id() {
		return f_id;
	}

	public void setF_id(int f_id) {
		this.f_id = f_id;
	}

	public double getTotalFees() {
		return totalFees;
	}

	public void setTotalFees(double totalFees) {
		this.totalFees = totalFees;
	}

	public int getNoOfInstallments() {
		return noOfInstallments;
	}

	public void setNoOfInstallments(int noOfInstallments) {
		this.noOfInstallments = noOfInstallments;
	}
	
	
	

}

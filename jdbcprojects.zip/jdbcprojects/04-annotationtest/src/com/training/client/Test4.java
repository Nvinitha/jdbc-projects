package com.training.client;
/**
 * 
 * @author vnarvane
 *
 */

public class Test4 
{
	/**
	 * 
	 * @param n number to be computed for square
	 * @return returns square of a number
	 */
	int square(int n)
	{
		return n*n;
	}


}




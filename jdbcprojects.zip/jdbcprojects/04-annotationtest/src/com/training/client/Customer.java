package com.training.client;

@Table(name = "Customer")
@Entity
public class Customer 
{
	@Id
	int id;
	
	@Coloumn(name="c_name",size=25, notNull=true )
	String name;
	
	@Coloumn(name="c_city",size=15, notNull=true)
	String city;
	double outStandingAmt;

}

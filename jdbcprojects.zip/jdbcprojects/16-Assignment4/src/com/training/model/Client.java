package com.training.model;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Client {

	public static void main(String[] args) {
		
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		em.getTransaction().begin();
		
		//create a new department
		Loan loan = new Loan();
		loan.setCustomerName("Tarak");
		loan.setLoanAmount(1000);
		loan.setLoanId(1);
		
		
		//create two instances of employees
		RePayment payment = new RePayment();
		payment.setRePaymentId(1);
		payment.setInstallmentNo(1);
		payment.setRePayAmount(500);
		
		RePayment payment1 = new RePayment();
		payment1.setRePaymentId(2);
		payment1.setInstallmentNo(2);
		payment1.setRePayAmount(500);
		
		//add both employees to department
		loan.addRepayment(payment);
		loan.addRepayment(payment1);
		
		//save department and its employees using entity manager
		em.persist(loan);
		
		System.out.println("Added loan along with two payments to database.");
		
		em.getTransaction().commit();
		em.close();
		factory.close();
	}
}

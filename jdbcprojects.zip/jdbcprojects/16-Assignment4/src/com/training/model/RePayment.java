package com.training.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class RePayment 
{
	@Id
	int rePaymentId;
	double rePayAmount;
	int installmentNo;
	@Override
	public String toString() {
		return "RePayment [rePaymentId=" + rePaymentId + ", rePayAmount="
				+ rePayAmount + ", installmentNo=" + installmentNo + "]";
	}
	public int getRePaymentId() {
		return rePaymentId;
	}
	public void setRePaymentId(int rePaymentId) {
		this.rePaymentId = rePaymentId;
	}
	public double getRePayAmount() {
		return rePayAmount;
	}
	public void setRePayAmount(double rePayAmount) {
		this.rePayAmount = rePayAmount;
	}
	public int getInstallmentNo() {
		return installmentNo;
	}
	public void setInstallmentNo(int installmentNo) {
		this.installmentNo = installmentNo;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + rePaymentId;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		RePayment other = (RePayment) obj;
		if (rePaymentId != other.rePaymentId)
			return false;
		return true;
	}
	public RePayment() {
		super();
	}
	public RePayment(int rePaymentId, double rePayAmount, int installmentNo) {
		super();
		this.rePaymentId = rePaymentId;
		this.rePayAmount = rePayAmount;
		this.installmentNo = installmentNo;
	}
	
	

}

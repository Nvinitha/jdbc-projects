package com.cg.jpastart.entities;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Main 
{
	public static void main(String[] args) 
	{
		EntityManagerFactory eFactory = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager eManager = eFactory.createEntityManager();
		Address address = eManager.find(Address.class, 1);
		System.out.println(address.getCity()+address.getZipCode()+address.getStudent().getName());
		
		Student student =  eManager.find(Student.class, 2);
		System.out.println(student.getAddress().getCity()+" "+student.getAddress().getZipCode()+" "+student.getName());
		
		eManager.close();
		eFactory.close();
		
		
		
	}

}

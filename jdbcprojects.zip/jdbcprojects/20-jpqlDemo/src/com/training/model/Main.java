package com.training.model;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Main {

	public static void main(String[] args) 
	{
		Person p1 = new Person("Tarak", 25, 10000, 'M');
		Person p2 = new Person("Ram", 30, 15000, 'M');
		Person p3 = new Person("Anu", 26, 12000, 'F');
		Person p4 = new Person("Sunitha", 27, 12000, 'F');
		Person p5 = new Person("Abhay", 20, 6000, 'M');
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = emf.createEntityManager();
		
		em.getTransaction().begin();
		
		em.persist(p1);
		em.persist(p2);
		em.persist(p3);
		em.persist(p4);
		em.persist(p5);
		
		em.getTransaction().commit();
		
		em.close();
		emf.close();

	}

}

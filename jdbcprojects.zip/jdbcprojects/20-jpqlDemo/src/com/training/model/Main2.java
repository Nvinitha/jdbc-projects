package com.training.model;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class Main2 {

	public static void main(String[] args) {
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		Query query = em.createNamedQuery("filterbySalaryRange");
		query.setParameter("startRange", 5000.00);
		query.setParameter("endRange", 7000.00);
		
		List<Person> persons = query.getResultList();
		
		for (Person p : persons) 
		{
			System.out.print(p.getPersonId()+"\t");
			System.out.print(p.getName()+"\t");
			System.out.print(p.getGender()+"\t");
			System.out.print(p.getSalary()+"\t");
			System.out.println(p.getAge());
			
		}

em.getTransaction().commit();
		
		em.close();
		emf.close();

	}

}

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="bankcustomer")
public class Customer 
{
	@ManyToMany(cascade = CascadeType.ALL)
	@JoinTable(name="Bank_Customers", joinColumns = { @JoinColumn(name = "Customer_id") }, inverseJoinColumns = { @JoinColumn(name = "Bank_id") })
	List<Bank> bankList = new ArrayList<Bank>();
	@Id
	int id;
	String name;
	@Temporal(TemporalType.DATE)
	Date dob;
	
	public void addBank(Bank bank)
	{
		this.bankList.add(bank);
	}

	public List<Bank> getBankList() {
		return bankList;
	}

	public void setBankList(List<Bank> bankList) {
		this.bankList = bankList;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	@Override
	public String toString() {
		return "Customer [bankList=" + bankList + ", dob=" + dob + ", id=" + id
				+ ", name=" + name + "]";
	}
	
	

}

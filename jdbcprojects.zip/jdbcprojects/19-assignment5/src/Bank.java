import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;


@Entity
@Table(name="bank")
public class Bank 
{
	@ManyToMany(fetch=FetchType.LAZY,mappedBy="bankList")
	List<Customer> custList = new ArrayList<Customer>();
	@Id
	int id;
	String name;
	String headOfficeLocation;
	
	public void addCustomer(Customer c)
	{
		this.custList.add(c);
	}

	public List<Customer> getCustList() {
		return custList;
	}

	public void setCustList(List<Customer> custList) {
		this.custList = custList;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getHeadOfficeLocation() {
		return headOfficeLocation;
	}

	public void setHeadOfficeLocation(String headOfficeLocation) {
		this.headOfficeLocation = headOfficeLocation;
	}

	@Override
	public String toString() {
		return "Bank [custList=" + custList + ", id=" + id + ", name=" + name
				+ ", headOfficeLocation=" + headOfficeLocation + "]";
	}
	
	
	

}

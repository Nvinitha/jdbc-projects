import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;


public class Client {

	public static void main(String[] args) 
	{
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = emf.createEntityManager();
		
		em.getTransaction().begin();

		// Defining Banks
		Bank icici = new Bank();
		icici.setId(1);
		icici.setName("ICICI");
		icici.setHeadOfficeLocation("Mumbai");
		
		Bank hdfc = new Bank();
		hdfc.setId(2);
		hdfc.setName("HDFC");
		hdfc.setHeadOfficeLocation("Kolkata");
		
		Bank kotak = new Bank();
		kotak.setId(3);
		kotak.setName("KOTAK");
		kotak.setHeadOfficeLocation("Hyderabad");
		
		Bank sbi = new Bank();
		sbi.setId(4);
		sbi.setName("STATE BANK OF INDIA");
		sbi.setHeadOfficeLocation("Hyderabad");
	
		Bank ab = new Bank();
		ab.setId(5);
		ab.setName("ANDHRA BANK");
		ab.setHeadOfficeLocation("Mumbai");
		
		//Adding customer 1
		
		Customer vinitha= new Customer();
		vinitha.setName("VINITHA");
		vinitha.setId(1);
		vinitha.setDob(new Date());
		
		vinitha.addBank(icici);
		vinitha.addBank(ab);
		vinitha.addBank(sbi);
		
		//Adding customer 2
		
				Customer prasanna= new Customer();
				prasanna.setName("PRASANNA");
				prasanna.setId(2);
				prasanna.setDob(new Date());
				
				prasanna.addBank(hdfc);
				prasanna.addBank(ab);
				prasanna.addBank(kotak);
		//Adding customer 3
				
				Customer priyanka= new Customer();
				priyanka.setName("PRIYANKA");
				priyanka.setId(3);
				priyanka.setDob(new Date());
				
				priyanka.addBank(icici);
				priyanka.addBank(hdfc);
				priyanka.addBank(kotak);
		//Adding customer 4
				
				Customer sindhu= new Customer();
				sindhu.setName("SINDHU");
				sindhu.setId(4);
				sindhu.setDob(new Date());
				
				sindhu.addBank(icici);
				sindhu.addBank(ab);
				sindhu.addBank(sbi);
				
//Adding customer 5
				
				Customer kavya= new Customer();
				kavya.setName("KAVYA");
				kavya.setId(5);
				kavya.setDob(new Date());
				
				kavya.addBank(hdfc);
				kavya.addBank(ab);
				kavya.addBank(sbi);
		
	//Adding customer 6
				
				Customer tarun= new Customer();
				tarun.setName("TARUN");
				tarun.setId(6);
				tarun.setDob(new Date());
				
				tarun.addBank(hdfc);
				tarun.addBank(kotak);
				tarun.addBank(ab);
				
	//Adding customer 7
				
						Customer teja= new Customer();
						teja.setName("TEJA");
						teja.setId(7);
						teja.setDob(new Date());
						
						teja.addBank(sbi);
						teja.addBank(icici);
						teja.addBank(kotak);
	//Adding customer 8
						
						Customer hema= new Customer();
						hema.setName("HEMA");
						hema.setId(8);
						hema.setDob(new Date());
						
						hema.addBank(ab);
						hema.addBank(hdfc);
						hema.addBank(kotak);
	//Adding customer 9
						
						Customer tarak= new Customer();
						tarak.setName("TARAK");
						tarak.setId(9);
						tarak.setDob(new Date());
						
						tarak.addBank(kotak);
						tarak.addBank(ab);
						tarak.addBank(hdfc);
						
		//Adding customer 10
						
						Customer ram= new Customer();
						ram.setName("RAM");
						ram.setId(10);
						ram.setDob(new Date());
						
						ram.addBank(hdfc);
						ram.addBank(ab);
						ram.addBank(sbi);
				
		//saving customers
						
			em.persist(vinitha);
			em.persist(ram);
			em.persist(tarak);
			em.persist(hema);
			em.persist(teja);
			em.persist(tarun);
			em.persist(kavya);
			em.persist(sindhu);
			em.persist(priyanka);
			em.persist(prasanna);
			
			System.out.println("Added customers to bank");
		em.getTransaction().commit();
		em.close();
		emf.close();
	

	}

}

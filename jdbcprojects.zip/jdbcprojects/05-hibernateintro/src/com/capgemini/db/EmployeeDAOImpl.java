package com.capgemini.db;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.capgemini.business.Employee;

public class EmployeeDAOImpl implements EmployeeDAO {

	@Override
	public boolean addEmployee(Employee employee) {
		try
		{
			EntityManagerFactory eFactory = Persistence.createEntityManagerFactory("JPA-PU");
			EntityManager eManager = eFactory.createEntityManager();
			eManager.getTransaction().begin();
			eManager.persist(employee);
			eManager.getTransaction().commit();
			eManager.close();
			eFactory.close();
			return true;
			
		}catch(Exception e)
		{
			return false;	
		}
		
		
	}

	@Override
	public boolean removeEmployee(int id) 
	{
		try
		{
			EntityManagerFactory eFactory = Persistence.createEntityManagerFactory("JPA-PU");
			EntityManager eManager = eFactory.createEntityManager();
			eManager.getTransaction().begin();
			com.capgemini.business.Employee e = eManager.find(Employee.class, 102);
			eManager.remove(id);
			eManager.getTransaction().commit();
			
			eManager.close();
			eFactory.close();
			return true;
			
			
			
		}catch(Exception e)
		{
			return false;	
		}
	
	}

	@Override
	public boolean updateEmployee(Employee employee) 
	{

		try
		{
			EntityManagerFactory eFactory = Persistence.createEntityManagerFactory("JPA-PU");
			EntityManager eManager = eFactory.createEntityManager();
			eManager.getTransaction().begin();
			
			eManager.merge(employee);
			eManager.getTransaction().commit();
			
			eManager.close();
			eFactory.close();
			return true;
			
			
			
		}catch(Exception e)
		{
			return false;	
		}
	}

	@Override
	public Employee findEmployee(int id) 
	{
		Employee emp = null;
		try
		{
			EntityManagerFactory eFactory = Persistence.createEntityManagerFactory("JPA-PU");
			EntityManager eManager = eFactory.createEntityManager();
			
		Employee e = eManager.find(Employee.class, id);
		
			
			eManager.close();
			eFactory.close();
			return emp;
			
			
			
		}catch(Exception e)
		{
			return emp;	
		}
		
	}

	@Override
	public List<Employee> getAllEmployees() 
	{
		List<Employee> empList= null;
		try
		{
			EntityManagerFactory eFactory = Persistence.createEntityManagerFactory("JPA-PU");
			EntityManager eManager = eFactory.createEntityManager();
			Query q = eManager.createQuery("from employee");
			empList = q.getResultList();
			eManager.close();
			eFactory.close();
			return empList;
			
		}
		catch(Exception e)
		{	return empList;
			
		}
	
	}

}

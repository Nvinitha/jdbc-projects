package com.capgemini.ui;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.capgemini.business.Employee;

/*
 * data updation
 */
public class Main3 
{
	public static void main(String[] args) 
	{
	
		
		EntityManagerFactory eFactory = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager eManager = eFactory.createEntityManager();
		Employee e = null;
		//loading data
		e= eManager.find(Employee.class, 102);
		//changing salary
		e.setBasicSalary(15000);
		
		//updating to database
		eManager.getTransaction().begin();
		eManager.merge(e);
		eManager.getTransaction().commit();
		
		eManager.close();
		eFactory.close();
		System.out.println("Updated Successfully");
		
	}

}

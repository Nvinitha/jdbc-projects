package com.capgemini.ui;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.capgemini.business.Employee;

/*
 * removing record
 * 1. first load the record
 * 2. on successful loading delete the record.
 * else there is no record present
 */
public class Main4 {

	public static void main(String[] args) 
	{
		EntityManagerFactory eFactory = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager eManager = eFactory.createEntityManager();
		Employee e = null;
		//loading data
		e= eManager.find(Employee.class, 102);
		
		// query to remove

		
		eManager.getTransaction().begin();
		eManager.remove(e);
		eManager.getTransaction().commit();
		
		eManager.close();
		eFactory.close();
		System.out.println("Removed Successfully");
		
		
	
	}

}

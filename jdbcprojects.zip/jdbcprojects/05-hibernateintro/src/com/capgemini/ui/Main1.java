package com.capgemini.ui;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.capgemini.business.Employee;

public class Main1 {

	public static void main(String[] args) 
	{
		//retrieving single record
		EntityManagerFactory eFactory = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager eManager = eFactory.createEntityManager();
		Employee employee = null;
		
		employee= eManager.find(Employee.class, 102); //to select the particular record.
		eManager.close();
		eFactory.close();
		System.out.println(employee);
	}

}

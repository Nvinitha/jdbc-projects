package com.capgemini.ui;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.capgemini.business.Contact;

public class Main5 
{public static void main(String[] args) {
	

	Contact contact1 = new Contact(101,"Vinitha","9703612617");
	Contact contact2 = new Contact(102,"Rama","9703612617");
	Contact contact3 = new Contact(103,"Sita","9703612617");
	Contact contact4 = new Contact(104,"Ravana","9703612617");
	
	EntityManagerFactory emf = Persistence.createEntityManagerFactory("JPA-PU");
	EntityManager em = emf.createEntityManager();
	
	em.getTransaction().begin();
	
	em.persist(contact1);
	em.persist(contact2);
	em.persist(contact3);
	em.persist(contact4);
	contact3.setPhoneNumber("9666629999");
	em.merge(contact3);
	em.getTransaction().commit();
	em.close();
	emf.close();
	
	Contact contact5 = null;
	emf = Persistence.createEntityManagerFactory("JPA-PU");
	em = emf.createEntityManager();
	contact5 = em.find(Contact.class, 101);
	contact5.setPhoneNumber("9177465955");
	
	em.merge(contact5);
	System.out.println(contact5.equals(contact1));
	em.close();
	emf.close();
	

}}

package com.capgemini.ui;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.capgemini.business.Employee;
/*
 * to create a new record
 * 1.create a EntityManagerFactory 
 * 2.create a Entity Transaction
 * 3.Begin the transaction
 * 4. do the operation
 * 5. commit transaction
 */
public class Main {

	public static void main(String[] args) 
	{
		EntityManagerFactory eFactory = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager eManager = eFactory.createEntityManager();
		Employee employee = new Employee();
		employee.setEmpId(103 );
		employee.setEmpname("Vinitha");
		employee.setEmpGender('F');
		employee.setBasicSalary(10000);
		employee.setEmpGrade('A');
		
		EntityTransaction entityTransaction = eManager.getTransaction();
		entityTransaction.begin();
		eManager.persist(employee);
		entityTransaction.commit();
		
		eManager.close();
		eFactory.close();
		System.out.println("Object stored in DataBase");

	}

}

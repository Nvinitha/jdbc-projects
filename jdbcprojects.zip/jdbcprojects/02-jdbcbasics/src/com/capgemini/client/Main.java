package com.capgemini.client;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Main 
{
	public static Connection createConnection() throws ClassNotFoundException, SQLException
	{
		Class.forName("com.mysql.jdbc.Driver"); //loading driver
		String dbURL = "jdbc:mysql://localhost:3306/demodb"; // url line
		String userName = "root";
		String password = "pass";
		Connection connection = DriverManager.getConnection(dbURL, userName, password);

		System.out.println("Connected Successfully");
		return connection;
	}
	public static void insertRecord() throws SQLException, ClassNotFoundException
	{
		Connection connection = createConnection();
		
		String  sql = "insert into customer values(6, 'Tarak', 'Hyderabad',8000)";
		Statement statement = connection.createStatement();
		int r = statement.executeUpdate(sql); //on successful execution r represents how many values are effected for the sql query 
		System.out.println(r +"Rows Inserted");
		statement.close();
		connection.close();

	}
	public static void updateRecord() throws SQLException, ClassNotFoundException
	{
		Connection connection = createConnection();
		String  sql = "update customer set c_amt = c_amt+2000 where c_id=1";
		Statement statement = connection.createStatement();
		int r = statement.executeUpdate(sql); //on successful execution r represents how many values are effected for the sql query 
		System.out.println(r +"Rows updated");
		statement.close();
		connection.close();

	}
	public static void deleteRecord() throws SQLException, ClassNotFoundException
	{
		Connection connection = createConnection();
		String  sql = "delete from customer  where c_id=5";
		Statement statement = connection.createStatement();
		int r = statement.executeUpdate(sql); //on successful execution r represents how many values are effected for the sql query 
		System.out.println(r +"Rows delete");
		statement.close();
		connection.close();

	}
	
	public static void displayAllRecords() throws SQLException, ClassNotFoundException
	{
		Connection connection = createConnection();
		String  sql = "select * from customer";
		Statement statement = connection.createStatement();
		ResultSet rs = statement.executeQuery(sql); //on successful execution rs represents total records fetched for the sql query 
		
		
		while(rs.next())
		{
		System.out.print(rs.getInt(1) + "\t");
		System.out.print(rs.getString(2)+ "\t");
		System.out.print(rs.getString(3)+ "\t");
		System.out.println(rs.getDouble(4)+ "\t");
		//System.out.println(rs +"Rows displayed");
		
		}
		rs.close();
		statement.close();
		connection.close();

	}
	
	public static void displayOneRecords(int id) throws SQLException, ClassNotFoundException
	{
		Connection connection = createConnection();
		String  sql = "select * from customer where c_id = "+id;
		Statement statement = connection.createStatement();
		ResultSet rs = statement.executeQuery(sql); //on successful execution rs represents total records fetched for the sql query 
		if(rs.next()){
		System.out.print(rs.getInt(1) + "\t");
		System.out.print(rs.getString(2)+ "\t");
		System.out.print(rs.getString(3)+ "\t");
		System.out.println(rs.getDouble(4)+ "\t");
		//System.out.println(rs +"Rows displayed");
		}
		else
		{
			System.out.println("No records fetched");
		}
		rs.close();
		statement.close();
		connection.close();

	}
	
	public static void main(String[] args) throws ClassNotFoundException, SQLException
	{
		//updateRecord();
		//deleteRecord();
		//displayAllRecords();
		displayOneRecords(5);
	}
	
}

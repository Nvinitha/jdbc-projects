package com.cg.jpastart.entities;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/*'
 * 
 */
public class Main {

public static void main(String[] args) 
{
	EntityManagerFactory eFactory = Persistence.createEntityManagerFactory("JPA-PU");
	EntityManager eManager = eFactory.createEntityManager();
	
	eManager.getTransaction().begin();
	Employee employee= eManager.find(Employee.class, 1001);
	System.out.println(employee.getName()+" "+employee.getSalary()+" "+employee.getDepartment().getName());
	eManager.getTransaction().commit();
	eManager.close();
	eFactory.close();
}
	
	
}

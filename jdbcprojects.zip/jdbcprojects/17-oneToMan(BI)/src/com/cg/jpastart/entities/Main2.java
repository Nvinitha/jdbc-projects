package com.cg.jpastart.entities;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Main2 
{
	public static void main(String[] args) 
	{
		EntityManagerFactory eFactory = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager eManager = eFactory.createEntityManager();
		
		eManager.getTransaction().begin();
		Department department= eManager.find(Department.class, 10);
		System.out.println(department.getEmployees().size());
		
		for (Employee e : department.getEmployees()) 
		{
			System.out.println(e.getName()+"\t"+e.getSalary());
			
		}
		eManager.getTransaction().commit();
		eManager.close();
		eFactory.close();
		
	}

}

package com.capgemini.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.capgemini.business.Customer;

public class CustomerDAOImpl implements CustomerDAO 
{

	public static Connection createConnection() throws ClassNotFoundException, SQLException
	{
		Class.forName("com.mysql.jdbc.Driver"); //loading driver
		String dbURL = "jdbc:mysql://localhost:3306/demodb"; // url line
		String userName = "root";
		String password = "pass";
		Connection connection = DriverManager.getConnection(dbURL, userName, password);

		System.out.println("Connected Successfully");
		return connection;
	}
	@Override
	public boolean addCustomer(Customer customer) throws ClassNotFoundException, SQLException 
	{
		Connection connection = createConnection();
		
	
		String  sql = "insert into customer values(?, ?, ?,?)";
		
		PreparedStatement statement =  connection.prepareStatement(sql);
		statement.setInt(1, customer.getId());
		statement.setString(2, customer.getName());
		statement.setString(3, customer.getCity());
		statement.setDouble(4, customer.getOutStandingAmount());
		int r = statement.executeUpdate(); //on successful execution r represents how many values are effected for the sql query 
		System.out.println(r +"Rows Inserted");
		statement.close();
		connection.close();
		
		if(r>0)
		{
			return true;
		}
		else 
		{
			return false;
		}
	}

	@Override
	public boolean removeCustomer(int customerId) throws ClassNotFoundException, SQLException 
	{
		Connection connection = createConnection();
		String  sql = "delete from customer  where c_id=?";
		PreparedStatement statement = (PreparedStatement) connection.prepareStatement(sql);
		statement.setInt(1, customerId);
		int rs = statement.executeUpdate(); //on successful execution r represents how many values are effected for the sql query 
		
		if(rs==1)
		{
		return true;
		
		}
		else
		{
			return false;
		}
		
		
	}

	@Override
	public boolean updateCustomer(Customer customer) throws ClassNotFoundException, SQLException 
	{
Connection connection = createConnection();
		
		int inp_id = 0;
		String inp_name = "";
		String inp_city = "";
		double inp_amt = 0.0;
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter ID : ");
		inp_id = scanner.nextInt();
		System.out.println("Enter Name : ");
		inp_name = scanner.next();
		System.out.println("Enter City : ");
		inp_city = scanner.next();
		System.out.println("Enter OutStanding amount : ");
		inp_amt = scanner.nextDouble();
		
		String  sql = "update customer set c_name=?,c_city=?,c_amt=? where c_id=? ";
		
		PreparedStatement statement =  connection.prepareStatement(sql);
		statement.setInt(4, inp_id);
		statement.setString(1, inp_name);
		statement.setString(2, inp_city);
		statement.setDouble(3, inp_amt);
		int r = statement.executeUpdate(); //on successful execution r represents how many values are effected for the sql query 
		System.out.println(r +"Rows Inserted");
		statement.close();
		connection.close();
		scanner.close();
		if(r>0)
		{
			return true;
		}
		else 
		{
			return false;
		}
		
		
	}

	@Override
	public boolean findCustomer(int customerId) 
	{
		
		return false;
	}

	@Override
	public List<Customer> getAllCustometers() throws ClassNotFoundException, SQLException 
	{	
		
		
		Connection connection = createConnection();
		String  sql = "select * from customer";
		Statement statement = connection.createStatement();
		ResultSet rs = statement.executeQuery(sql); //on successful execution rs represents total records fetched for the sql query 
		List<Customer> custList = new ArrayList<>();
		
		while(rs.next())
		{
		int id = rs.getInt(1);
		String name = rs.getString(2);
		String city = rs.getString(3);
		double amt=rs.getDouble(4);
		Customer customer = new Customer();
		customer.setId(id);
		customer.setName(name);
		customer.setCity(city);
		customer.setOutStandingAmount(amt);
		custList.add(customer);
		}
		rs.close();
		statement.close();
		connection.close();
		
		return custList;
	}

}

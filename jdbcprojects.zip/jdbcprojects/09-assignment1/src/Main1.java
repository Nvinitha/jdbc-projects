import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;


public class Main1 
{
	public static void main(String[] args) 
	{
		EntityManagerFactory emf1 = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = emf1.createEntityManager();
		
		em.getTransaction().begin();

		Doctor doctor = new Doctor();
		
		doctor.setName("vinitha");
		doctor.setFees(100);
	
		Qualification qualification = new Qualification();
		qualification.setExperience(5);
		qualification.setNameOfQualification("MBBS");
		doctor.setQualification(qualification);
		
		em.persist(doctor);
		
		em.getTransaction().commit();
		em.close();
		emf1.close();
		
	}
	
}

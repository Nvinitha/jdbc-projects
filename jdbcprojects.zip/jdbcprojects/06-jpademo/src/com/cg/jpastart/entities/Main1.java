package com.cg.jpastart.entities;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;



public class Main1 
{
	public static void main(String[] args) 
	{
		EntityManagerFactory eFactory = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager eManager = eFactory.createEntityManager();
		Student student=null;
	
		String myQuery="from Student"; 
		Query query = eManager.createQuery(myQuery);
		List<Student> stuList =null;

		stuList = query.getResultList();
for (Student s1 : stuList) 
{
	eManager.getTransaction().begin();
	s1.setName(s1.getName().toUpperCase());
	eManager.merge(s1);
	eManager.getTransaction().commit();
}

		
		eManager.close();
		eFactory.close();
	
		
		
	}

}

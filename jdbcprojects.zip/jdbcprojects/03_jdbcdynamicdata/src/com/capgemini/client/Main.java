package com.capgemini.client;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;


public class Main 
{
	public static Connection createConnection() throws ClassNotFoundException, SQLException
	{
		Class.forName("com.mysql.jdbc.Driver"); //loading driver
		String dbURL = "jdbc:mysql://localhost:3306/demodb"; // url line
		String userName = "root";
		String password = "pass";
		Connection connection = DriverManager.getConnection(dbURL, userName, password);

		System.out.println("Connected Successfully");
		return connection;
	}
	public static void insertRecord() throws SQLException, ClassNotFoundException
	{
		Connection connection = createConnection();
		
		int inp_id = 0;
		String inp_name = "";
		String inp_city = "";
		double inp_amt = 0.0;
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter ID : ");
		inp_id = scanner.nextInt();
		System.out.println("Enter Name : ");
		inp_name = scanner.next();
		System.out.println("Enter City : ");
		inp_city = scanner.next();
		System.out.println("Enter OutStanding amount : ");
		inp_amt = scanner.nextDouble();
		
		String  sql = "insert into customer values(?, ?, ?,?)";
		
		PreparedStatement statement =  connection.prepareStatement(sql);
		statement.setInt(1, inp_id);
		statement.setString(2, inp_name);
		statement.setString(3, inp_city);
		statement.setDouble(4, inp_amt);
		int r = statement.executeUpdate(); //on successful execution r represents how many values are effected for the sql query 
		System.out.println(r +"Rows Inserted");
		statement.close();
		connection.close();
		scanner.close();

	}
	
	public static void updateRecord() throws SQLException, ClassNotFoundException
	{
		Connection connection = createConnection();
		Scanner scanner =  new Scanner(System.in);
		System.out.println("Enter Amount to add : ");
		double inp_amt = scanner.nextDouble();
		System.out.println("Enter ID to add : ");
		int inp_id = scanner.nextInt();
		String  sql = "update customer set c_amt = c_amt+? where c_id=?";
		PreparedStatement statement =  connection.prepareStatement(sql);
		statement.setInt(2, inp_id);
		statement.setDouble(1, inp_amt);
		
		int r = statement.executeUpdate(); //on successful execution r represents how many values are effected for the sql query 
		System.out.println(r +"Rows updated");
		statement.close();
		connection.close();
		scanner.close();
	}
	public static void deleteRecord() throws SQLException, ClassNotFoundException
	{
		Connection connection = createConnection();
		int id;
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter ID : ");
		id = scanner.nextInt();
		String  sql = "delete from customer  where c_id=?";
		PreparedStatement statement = (PreparedStatement) connection.prepareStatement(sql);
		statement.setInt(1, id);
		int rs = statement.executeUpdate(); //on successful execution r represents how many values are effected for the sql query 
		System.out.println(rs +"row deleted successfully");
		statement.close();
		connection.close();
		scanner.close();
	}
	
	public static void displayAllRecords() throws SQLException, ClassNotFoundException
	{
		Connection connection = createConnection();
		String  sql = "select * from customer";
		Statement statement = connection.createStatement();
		ResultSet rs = statement.executeQuery(sql); //on successful execution rs represents total records fetched for the sql query 
		
		
		while(rs.next())
		{
		System.out.print(rs.getInt(1) + "\t");
		System.out.print(rs.getString(2)+ "\t");
		System.out.print(rs.getString(3)+ "\t");
		System.out.println(rs.getDouble(4)+ "\t");
		//System.out.println(rs +"Rows displayed");
		
		}
		rs.close();
		statement.close();
		connection.close();

	}
	
	public static void displayOneRecord() throws SQLException, ClassNotFoundException
	{
		Connection connection = createConnection();
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter id to display");
		int inp_id = scanner.nextInt();
		String  sql = "select * from customer where c_id = ?";
		PreparedStatement statement = connection.prepareStatement(sql);
		statement.setInt(1, inp_id);
		ResultSet rs = statement.executeQuery(); //on successful execution rs represents total records fetched for the sql query 
		if(rs.next()){
		System.out.print(rs.getInt(1) + "\t");
		System.out.print(rs.getString(2)+ "\t");
		System.out.print(rs.getString(3)+ "\t");
		System.out.println(rs.getDouble(4)+ "\t");
		//System.out.println(rs +"Rows displayed");
		scanner.close();
		}
		else
		{
			System.out.println("No records fetched");
		}
		rs.close();
		statement.close();
		connection.close();

	}
	
	public static void main(String[] args) throws ClassNotFoundException, SQLException
	{
		//insertRecord();
		//updateRecord();
		//deleteRecord();
		//displayAllRecords();
		displayOneRecord();
	}
	
}

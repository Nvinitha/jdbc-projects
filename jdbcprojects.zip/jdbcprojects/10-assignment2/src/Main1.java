import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;


public class Main1 
{
	public static void main(String[] args) 
	{
		EntityManagerFactory eFactory = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager eManager = eFactory.createEntityManager();
		
		eManager.getTransaction().begin();
		FeeDetails details = new FeeDetails();
		
		details.setNoOfInstallments(2);
		details.setTotalFees(10000);
		
		Courses courses = new Courses();
		
		courses.setC_name("ABCD");
		
	courses.setFees(details);
	eManager.persist(courses);
		
		eManager.getTransaction().commit();
		eManager.close();
		eFactory.close();
		
	}

}
